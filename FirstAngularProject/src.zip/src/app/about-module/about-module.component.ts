import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-module',
  templateUrl: './about-module.component.html',
  styleUrls: ['./about-module.component.css']
})
export class AboutModuleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
