import { Submit } from './submit';

describe('Submit', () => {
  it('should create an instance', () => {
    expect(new Submit()).toBeTruthy();
  });
});
