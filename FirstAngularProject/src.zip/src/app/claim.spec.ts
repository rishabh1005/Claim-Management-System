import { Claim } from './claim';

describe('Claim', () => {
  it('should create an instance', () => {
    expect(new Claim()).toBeTruthy();
  });
});
