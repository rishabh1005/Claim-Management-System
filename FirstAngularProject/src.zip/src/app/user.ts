/**
* User Model class
*/
export class User {
    memberId!: string;
    username!:string;
    password!:string;
}
